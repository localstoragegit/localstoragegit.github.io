
Please read https://github.com/coreos/etcd/blob/master/CONTRIBUTING.md#contribution-flow.
