
Please read https://github.com/coreos/etcd/blob/master/Documentation/reporting_bugs.md.
